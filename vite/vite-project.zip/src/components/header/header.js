const header = () => {
  console.log('header');
};

export default header;