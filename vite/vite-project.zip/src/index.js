import header from './components/header/header.js';

console.log('index.js');
header();